<?php

declare(strict_types=1);

namespace Drupal\FunctionalTests\Recipe\Core\article_content_type;

use Drupal\Tests\system\Functional\Recipe\GenericRecipeTestBase;

/**
 * @group core_article_content_type_recipe
 */
class GenericTest extends GenericRecipeTestBase {}

<?php

declare(strict_types=1);

namespace Drupal\FunctionalTests\Recipe\Core\article_tags;

use Drupal\Tests\system\Functional\Recipe\GenericRecipeTestBase;

/**
 * @group core_article_tags_recipe
 */
class GenericTest extends GenericRecipeTestBase {}

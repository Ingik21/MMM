<?php

declare(strict_types=1);

namespace Drupal\FunctionalTests\Recipe\Core\remote_video_media_type;

use Drupal\Tests\system\Functional\Recipe\GenericRecipeTestBase;

/**
 * @group core_remote_video_media_type_recipe
 */
class GenericTest extends GenericRecipeTestBase {}

<?php

declare(strict_types=1);

namespace Drupal\FunctionalTests\Recipe\Core\basic_html_format_editor;

use Drupal\Tests\system\Functional\Recipe\GenericRecipeTestBase;

/**
 * @group core_basic_html_format_editor_recipe
 */
class GenericTest extends GenericRecipeTestBase {}

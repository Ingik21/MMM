<?php

declare(strict_types=1);

namespace Drupal\FunctionalTests\Recipe\Core\article_comment;

use Drupal\Tests\system\Functional\Recipe\GenericRecipeTestBase;

/**
 * @group core_article_comment_recipe
 */
class GenericTest extends GenericRecipeTestBase {}

<?php

declare(strict_types=1);

namespace Drupal\FunctionalTests\Recipe\Core\user_picture;

use Drupal\Tests\system\Functional\Recipe\GenericRecipeTestBase;

/**
 * @group core_user_picture_recipe
 */
class GenericTest extends GenericRecipeTestBase {}

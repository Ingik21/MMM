
ABOUT STABLE 9
--------------

Stable 9 allows core markup and styling to evolve by functioning as a backwards
compatibility layer for themes against changes to core markup and CSS. If you
browse Stable 9's contents, you will find copies of all the Twig templates and
CSS files provided by core.

Warning: Themes that decide to not use Stable 9 as a base theme will need
continuous maintenance as core changes, so only opt out if you are prepared to
keep track of those changes and how they affect your theme.

ABOUT DRUPAL THEMING
--------------------

For more information, see Drupal.org's theming guide.
https://www.drupal.org/docs/8/theming
